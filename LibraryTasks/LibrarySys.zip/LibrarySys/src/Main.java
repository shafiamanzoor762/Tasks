
public class Main {
	public static void main(String[] args) {
        Library lib = new Library();
        lib.readItemData();        
        lib.printAllItems();
        lib.printAllUsers();
    }
}
