public class LibraryItem {
    private String title;
    private String itemCode;
    private int cost;
    private int timesBorrowed;
    private boolean onLoan;

    public LibraryItem(String title, String itemCode, int cost, int timesBorrowed, boolean onLoan) {
        this.title = title;
        this.itemCode = itemCode;
        this.cost = cost;
        this.timesBorrowed = timesBorrowed;
        this.onLoan = onLoan;
    }
    
    public String getTitle() {
        return title;
    }

    public String getItemCode() {
        return itemCode;
    }

    public int getCost() {
        return cost;
    }

    public int getTimesBorrowed() {
        return timesBorrowed;
    }

    public boolean isOnLoan() {
        return onLoan;
    }

    public void printDetails() {
        String loanStatus = onLoan ? "This item is at present on loan" : "This item is not on loan";
        System.out.println("----------------------------------\n" + title + " with item code " + itemCode + " has been borrowed " + timesBorrowed +
                " times.\n" + loanStatus + " and when new cost " + cost + " pence.");
    }
}
