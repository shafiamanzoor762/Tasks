import java.awt.FileDialog;
import java.awt.Frame;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Library {
    private ArrayList<LibraryItem> itemList;

    public Library() {
        this.itemList = new ArrayList<>();
    }
    public void storeItem(LibraryItem item) {
        itemList.add(item);
    }

    public void printAllItems() {
        for (LibraryItem item : itemList) {
            item.printDetails();
        }
    }

    public void readItemData() {
        // Parent frame for the file dialog
        Frame parentFrame = new Frame();

        // FileDialog object with the parent frame
        FileDialog fileDialog = new FileDialog(parentFrame, "Select item data file");
        fileDialog.setMode(FileDialog.LOAD);
        fileDialog.setVisible(true);

        // Get the selected file
        String selectedFile = fileDialog.getFile();
        if (selectedFile == null) {
            System.out.println("No file selected.");
            return;
        }

        try {
            // Set up scanner to read from the selected file
            Scanner scanner = new Scanner(new File(fileDialog.getDirectory() + selectedFile));

            while (scanner.hasNextLine()) {
                String lineOfText = scanner.nextLine().trim(); // Remove leading/trailing spaces
                if (!lineOfText.startsWith("//") && !lineOfText.isEmpty()) {
                    // Process real data
                    System.out.println(lineOfText); // Output the line to check

                    // Split the line into tokens
                    Scanner lineScanner = new Scanner(lineOfText);
                    lineScanner.useDelimiter(",");

                    // Read data for each field
                    String title = lineScanner.next();
                    String itemCode = lineScanner.next();
                    int cost = lineScanner.nextInt();
                    int timesBorrowed = lineScanner.nextInt();
                    boolean onLoan = lineScanner.nextBoolean();

                    // Create LibraryItem object and store it
                    LibraryItem item = new LibraryItem(title, itemCode, cost, timesBorrowed, onLoan);
                    storeItem(item);

                    // Close the line scanner
                    lineScanner.close();
                }
            }

            // Close the main scanner
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        Library library = new Library();
        library.readItemData();
        library.printAllItems();
    }
}
