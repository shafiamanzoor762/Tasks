
public class Main {
	public static void main(String[] args) {
        Library lib = new Library();
        lib.readBookData();        
        lib.printAllBooks();
        lib.printAllUsers();
    }
}
